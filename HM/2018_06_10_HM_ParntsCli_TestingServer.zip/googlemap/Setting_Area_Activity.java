package com.example.person.googlemap;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Setting_Area_Activity extends Activity{
    String setArea;
    String name;
    EditText ed_name;
    EditText ed_meter;

    @Override
    protected void onCreate(Bundle saveInstanceState)
    {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.set_tag_meter);
        ed_name = (EditText)findViewById(R.id.setname);
        ed_meter = (EditText)findViewById(R.id.setmeter);
    }

    public void OK(View view)
    {
        name = ed_name.getText().toString();
        setArea = ed_meter.getText().toString();
        Intent result = new Intent();
        result.putExtra("Settingname", name);
        result.putExtra("Settingarea", setArea);
        setResult(1001, result);
        finish();
    }
}
